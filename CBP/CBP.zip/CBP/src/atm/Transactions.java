package atm;

import java.util.Date;

public class Transactions {
	private Date timeStamp;
	private String action;
	private double amount;

}
